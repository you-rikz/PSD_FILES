<?php
use \Tamtamchik\SimpleFlash\Flash;

global $flash;
$flash = new Flash();